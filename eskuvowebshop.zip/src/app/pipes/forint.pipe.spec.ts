import { ForintPipe } from './forint.pipe';

describe('ForintPipe', () => {
  it('create an instance', () => {
    const pipe = new ForintPipe();
    expect(pipe).toBeTruthy();
  });
});
