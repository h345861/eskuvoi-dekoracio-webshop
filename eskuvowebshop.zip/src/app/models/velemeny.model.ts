export interface Velemeny {
  id?: string;
  uid: string;
  nev: string;
  szoveg: string;
  datum: Date;
}
