export interface KosarElem {
  id: number;
  nev: string;
  ar: number;
  kep: string; 
  mennyiseg: number;
  hazhozszallitas?: boolean;
}