export interface Termek {
  id?: string;
  nev: string;
  kategoria: string;
  ar: number;
  kepUrl: string;
  leiras?: string;
}
